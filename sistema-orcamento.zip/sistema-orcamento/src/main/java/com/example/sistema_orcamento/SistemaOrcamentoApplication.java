package com.example.sistema_orcamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaOrcamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaOrcamentoApplication.class, args);
	}

}
