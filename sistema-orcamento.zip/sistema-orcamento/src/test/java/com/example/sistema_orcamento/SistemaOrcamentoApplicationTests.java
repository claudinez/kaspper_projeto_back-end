package com.example.sistema_orcamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaOrcamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
